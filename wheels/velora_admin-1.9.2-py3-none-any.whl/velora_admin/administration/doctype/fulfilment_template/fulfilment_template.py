"""Fulfilment Template native DocType."""
